@echo off
setlocal EnableDelayedExpansion

:: Clear screen and display welcome message
cls
echo ==================================================
echo           Welcome to FlowDriver Launcher          
echo ==================================================
echo.

:: Check if credentials.json exists
if not exist "credentials.json" (
    echo [ERROR] 'credentials.json' not found in the current directory.
    echo Please place your 'credentials.json' file in this folder and run the script again.
    echo.
    pause
    exit /b 1
)

:: Prompt the user to manually enter their Google Folder ID
set /p FOLDER_ID="Please enter your Google Folder ID: "

:: Remove surrounding quotes or spaces if any
set "FOLDER_ID=%FOLDER_ID:"=%"
set "FOLDER_ID=%FOLDER_ID: =%"

if "!FOLDER_ID!"=="" (
    echo [ERROR] Google Folder ID cannot be empty.
    echo.
    pause
    exit /b 1
)

:: Automatically create/overwrite client_config.json
echo { > client_config.json
echo   "listen_addr": "127.0.0.1:1080", >> client_config.json
echo   "storage_type": "google", >> client_config.json
echo   "folder_id": "!FOLDER_ID!", >> client_config.json
echo   "refresh_rate_ms": 200, >> client_config.json
echo   "flush_rate_ms": 300, >> client_config.json
echo   "transport": { >> client_config.json
echo     "TargetIP": "216.239.38.120:443", >> client_config.json
echo     "SNI": "google.com", >> client_config.json
echo     "HostHeader": "www.googleapis.com", >> client_config.json
echo     "InsecureSkipVerify": false >> client_config.json
echo   } >> client_config.json
echo } >> client_config.json

echo.
echo [SUCCESS] 'client_config.json' has been successfully created.

:: Detect OS. Since this is a batch script, the OS is Windows.
set BINARY_NAME=client.exe

:: Execute the compiled FlowDriver client binary
if not exist "!BINARY_NAME!" (
    echo [ERROR] Executable '!BINARY_NAME!' not found in the current directory.
    echo Please ensure you have placed the Windows binary here.
    echo.
    pause
    exit /b 1
)

echo [INFO] Starting FlowDriver client...
echo [INFO] Command: !BINARY_NAME! -c client_config.json -gc credentials.json
echo ==================================================
echo.

!BINARY_NAME! -c client_config.json -gc credentials.json

echo.
echo [INFO] FlowDriver client has stopped.
pause
